angular.module('kolibriWebApp', ['ngRoute','ngAnimate', 'ngSanitize', 'ui.bootstrap']);
angular.module('kolibriWebApp').controller('PaginationDemoCtrl', function ($scope, $log, $http) {

    $scope.submitSearchCustomer = function() {
        /* Haku logiikka tänne */
        if ($scope.hakukriteerit) { // IF SET OR NOT EMPTY
        alert($scope.hakukriteerit);
            $http.get('https://jsonplaceholder.typicode.com/comments').
                success(function(data, status, headers, config) {
                    $scope.maxSize = 5;
                    $scope.bigTotalItems = data.length;
                    $scope.bigCurrentPage = 1;
                    var arrayEnd = $scope.bigCurrentPage * 10;
                    var arrayBeg = arrayEnd - 10;
                    $scope.hakuData = data;
                    $scope.hakuData2 = $scope.hakuData.slice(arrayBeg, arrayEnd); 
            
                    /*
                    if(data.length >= 10) {
                        for(var i = 0; i < 10; i++) {
                            $scope.hakuData.push(data(i));    
                        }
                        alert(data);
                    } else {
                        $scope.hakuData = data; 
                    }*/
              }).error(function(data, status, headers, config) {
                    $scope.hakuResponse = "";
            });
    
        }
    };


    $scope.setPage = function (pageNo) {
        $scope.bigCurrentPage = pageNo;
        var arrayEnd = $scope.bigCurrentPage * 10;
        var arrayBeg = arrayEnd - 10;
        $scope.hakuData2 = $scope.hakuData.slice(arrayBeg, arrayEnd);
    };



});