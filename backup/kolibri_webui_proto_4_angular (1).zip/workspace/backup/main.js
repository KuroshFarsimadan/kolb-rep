/**
 * Main AngularJS Web Application
 */
var app = angular.module('kolibriWebApp', [
  'ngRoute', 'ui.bootstrap.demo'
]);

/**
 * Configure the Routes
 */
app.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
    // Home
    .when("/", {templateUrl: "partials/home.html", controller: "PageCtrl"})
    // Pages
    .when("/about", {templateUrl: "partials/about.html", controller: "PageCtrl"})
    .when("/faq", {templateUrl: "partials/faq.html", controller: "PageCtrl"})
    .when("/asiakkaat", {templateUrl: "partials/asiakkaat.html", controller: "asiakkaatController"})
    .when("/services", {templateUrl: "partials/services.html", controller: "PageCtrl"})
    .when("/contact", {templateUrl: "partials/contact.html", controller: "PageCtrl"})
    // Blog
    .when("/blog", {templateUrl: "partials/blog.html", controller: "BlogCtrl"})
    .when("/blog/post", {templateUrl: "partials/blog_item.html", controller: "BlogCtrl"})
    // else 404
    .otherwise("/404", {templateUrl: "partials/404.html", controller: "PageCtrl"});
}]);

/**
 * Controls the Blog
 */
app.controller('BlogCtrl', function (/* $scope, $location, $http */) {
  console.log("Blog Controller reporting for duty.");
});

/**
 * Controls all other Pages

app.controller('asiakkaatController', function ($scope, $http) {
  $scope.itemLimit = 10;
  
  $scope.pagination = function(nextPage) {
    $scope.tenData = [];
    $scope.nextPage = 10 * nextPage; 
    alert($scope.nextPage);
    var currentPage = $scope.nextPage - 10;
    for (var i = currentPage; i < $scope.nextPage; i++) {
      $scope.tenData.push($scope.hakuData);
    }    
  };

  
  $scope.submitSearchCustomer = function() {
    if ($scope.hakukriteerit) {
      $http.get('https://jsonplaceholder.typicode.com/comments').
      success(function(data, status, headers, config) {
        
          $scope.hakuResponse = "";
          $scope.hakuData = data;
          
          $scope.currentPage = 1;
          $scope.pageSize = 10;
          $scope.tenData = [];
          $scope.pageCount = []; 
          
          var numberOfPages = $scope.hakuData.length / 10;
          for(var b=1; b<=numberOfPages; b++) {
            $scope.pageCount.push(b);  
          }
          
          for (var i = 0; i < 10; i++) {
            $scope.tenData.push($scope.hakuData[i]);
          }
          $scope.pageChangeHandler = function(num) {
              console.log('meals page changed to ' + num);
          };
          
      }).error(function(data, status, headers, config) {
          $scope.hakuResponse = "<center><div class='alert alert-danger' role='alert'>Haulle " + $scope.hakukriteerit + " ei löytynyt hakutuloksia!</div></center>";
      });

    }
  };
});
 *//* if pagination value is 3, then 3*10=30 */

app.controller('PaginationDemoCtrl', function ($scope, $log) {
  $scope.totalItems = 64;
  $scope.currentPage = 4;

  $scope.setPage = function (pageNo) {
    $scope.currentPage = pageNo;
  };

  $scope.pageChanged = function() {
    $log.log('Page changed to: ' + $scope.currentPage);
  };

  $scope.maxSize = 5;
  $scope.bigTotalItems = 175;
  $scope.bigCurrentPage = 1;
});